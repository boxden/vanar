// closure 2 // замыкание
(function(){
  alert("Hi");
})(); // ОДНОРАЗОВАЯ ФУНКЦИЯ
///////////////////////////
(function( x ){
  alert( x*x );
})(11);
// 1 - resourses econom
// 2 - isolate variables


// learn.javascript.ru

// jquery
(function f(){ local v1 })();
f()
// jquery plugin
(function(){ local v1 })
