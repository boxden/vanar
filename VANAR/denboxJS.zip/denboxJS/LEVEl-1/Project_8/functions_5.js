var t = setInterval(f(){}, 1000)

clearInterval( t );
