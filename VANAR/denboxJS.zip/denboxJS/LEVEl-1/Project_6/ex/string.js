// String -> text
"Hello, text";
'Hello, text';
`Hello, {$}text`;

// Osnova
.length // -> skolko simvolov DLINNA
"hello, text" + "!";
"Hello, text".perlace( "Hello" ,"Hi"); // -> replace (ZAMENA)
"Hello, text".toUpperCase();
"Hello, text".toLowerCase();
 mdn js ;// -<> Site very good
 indexOf ;// -> Search
 "Hello, text".search("text");
 "Hello, text".concat(); // ->...
 "Hello, text".italics();
 "Dorin".trim(); // -> Чистит пробелы
 "Hello, text".substring(7,2); // -> С седьмой позиции он возьмёт 2 буквы
 "Hello, text".charAt(7);
 "Hello, text".toUpperCase();
 "Hello, text".toLocaleUpperCase();
 "Hello, text".toLowerCase();
 "Hello, text".toUpperCase();
 "Hello, text".slice(2,4); // -> индекс 2 до индекс 4 вырезать
 "Hello text" .split(" "); // -> поделить на пробел
 "Hello, text".split(",");
 "Hello, text".split(" ","");
 "Hello, text".replace();
 при помощи промпт прочитать имя и фамилие человека в 2 отдельные переменные
 иван прокопан
 вывести его инициаллы
" I.P."
//--------------------------------------------------
var name = "Ivan"
name[0]
name[0] + "."
alert( name[0] + "." )
alert( name.substring(0,1) + "." )
//--------------------------------------------------
дз посмотреть на концепт сет
при помощи цикла

var images = [
  "images",
  "images/my2.jpeg",
  "httpimages",
  "images/my4.jpeg",
];
(for, for in , while)
String
// 1)

/*
1.jpg (external) -jpeg image
my2.jpg (local) - jpeg image
my3.jpg (external) -jpeg image
4.jpg (local) - png image
*/
// 2)
// 3)
