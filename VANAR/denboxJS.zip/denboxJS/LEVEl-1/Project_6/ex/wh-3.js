var prices = [
/*0*/  12.50,   //milk
/*1*/  3.25 ,   // bread
/*2*/  1075.00, //vodra
];

// 1)
var bread_price = pricesp[ 1 ];
// 2)
bread_price++; // -> 4.25
// 3)
price[ 1 ]++; // -> 4.25
// 4)
var index = 2;
console.log( prices[ index ] ); // -> 1075.00
