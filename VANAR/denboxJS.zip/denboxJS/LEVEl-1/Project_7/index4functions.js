//// functions
//
// search() , pop(), alert()
//
////


function name( argument1, arg2, arg3, ){
  code_to_execute;
  return value;
}

// В этой формуле наме это название функции
// при помощи эти х переменных можно менять значение
// при помощи аргументов можно менять переменные
//
function hello(){
  alert("Hello");
}
