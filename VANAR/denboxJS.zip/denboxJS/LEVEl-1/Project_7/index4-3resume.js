function hello( name1 , name2 ){
  console.log("Hello " + name1 + "and" + name2 + "!" );
}


hello( "John", "Marry" );
//создать функцию 3 числа  10 9 8 и средняя 9
//функция выводит среднюю орефмитическую

function number( number1 , number2 , number3 ){
  console.log("Number" + number1 + "and" + number2 + "and" + number3 );
}
number( 10, 9 , 8 );
