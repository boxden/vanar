function hello( name ){
  console.log("Hello " + name + "!");
}


hello( "John" );
