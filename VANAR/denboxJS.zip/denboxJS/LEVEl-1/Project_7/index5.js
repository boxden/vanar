var hello = function(){
  console.log( "Hello!" );
}
;

hello();
