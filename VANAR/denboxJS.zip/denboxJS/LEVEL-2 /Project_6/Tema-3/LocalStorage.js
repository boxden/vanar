window.localStorage
window.sessionStorage

localStorage.setItem("key","value");
localStorage.removeItem("key","value");
localStorage.getItem("key");
localStorage.key("value");
localStorage.length,


localStorage.key(1),

document.cookie;
for (var i = 0; i < localStorage.length; i++) {
  console.log( localStorage.key(i), localStorage.getItem(i), );
}

JSON.parse( ); // JSON(string) ->>> Object
