event handler ( callback );

event.target
сыллка на елемент где он радился

isTrusted

currentTarget

cancelable

preventDefault()
stopPropagation() - Блокировка 
