/// <reference path="globals/socket.io-client/index.d.ts" />
