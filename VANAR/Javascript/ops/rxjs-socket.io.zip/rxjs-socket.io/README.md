# rxjs-socket.io

Here is how to run the code

Server:
From the server folder 

1-npm install

2-node server.js

Client:
From the client folder 

1-npm install

2-typings install

3-ng serve (assumes Angular CLI)
