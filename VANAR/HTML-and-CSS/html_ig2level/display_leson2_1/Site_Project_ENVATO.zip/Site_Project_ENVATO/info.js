/*

APEXO LANDIN PAGE DE PE THEMEFOREST

https://themeforest.net/item/appexo-app-landing-page/20097319?s_rank=4

~~~~~~~~~~~~~~~~~~~~1STEPT~~~~~~~~~~~~~~~~~~~~~~~
1) Connectam "reset CSS" la styles pentru Xbrowser

http://html5doctor.com/html-5-reset-stylesheet/

~~~~~~~~~~~~~~~~~~~~2STEPT~~~~~~~~~~~~~~~~~~~~~~~

apx_reset.css --adaugam reset features de alenoastre

EX:body{
font-size: 16px;  ~~~ 1rem = 16px ~~~

~~~~~~~~~~~~~~~~~~~~3STEPT~~~~~~~~~~~~~~~~~~~~~~~

F12 --verificam daca sunt conecatete css

~~~~~~~~~~~~~~~~~~~~4STEPT~~~~~~~~~~~~~~~~~~~~~~~
LA TOATE LINKURILE

target="_blank"---SA SE DESCHIDA IN PAGINA NOUA.

~~~~~~~~~~~~~~~~~~~~5STEPT~~~~~~~~~~~~~~~~~~~~~~~

la imagini din alta mapa
se da adresa astfel
(../img/bg1.png)~~~~~~ 2puncte ridicamai sus pe ieerarhie.

~~~~~~~~~~~~~~~~~~~~ 6 STEPT~~~~~~~~~~~~~~~~~~~~~~~

am facut in buton cu id settings #settings pentru a schimba backgroundul

~~~~~~~~~~~~~~~~~~~~  7 STEPT~~~~~~~~~~~~~~~~~~~~~~~

connectam google font-size


















*/
