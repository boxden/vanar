function f(){

  // var x;
  console.log("xxxxxx");
  if (true) {

  }
  /*var*/x = 10;
  x++;
  x--;



}
