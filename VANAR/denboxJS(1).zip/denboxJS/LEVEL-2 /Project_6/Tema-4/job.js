function save(){
  var save = document.querySelectorw
  //console.log( "G" );
  localStorage.setItem("");
}
