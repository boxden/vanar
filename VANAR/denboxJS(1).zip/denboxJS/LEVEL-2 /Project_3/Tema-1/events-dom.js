Event (DOM) // <<<<< Browser

Window
Document
Mouse
Keyboard
Frame/Object
Form
Drag
Clipboard
Print
Media
Animation
Transition
Server-Sent
Misc
Touch
