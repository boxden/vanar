// XmlHttpRequest -> xhr
 function load(){
   // AJAX
   // xhr -> connection
   var xhr = new XMLHttpRequest();

   // Данная функция отриагирует на любое изменение
   xhr.onreadystatechange = function(){
      // 4 - done
      // 200 - Ok
      console.log( xhr.readyState );
      if (xhr.readyState == 4 && xhr.status == 200) {
         var div = document.getElementById("content");
         div.innerHTML = xhr.responseText;
      }
   };

   // prepare the request
   xhr.open( "GET", "message.txt" );
   // send the request
   xhr.send();
 }

















// AJAX - Это часть Жава скрипта (Технология)
      // Динамическая загрузка , Как у гугл
      // Асинхронность . Ленивая загрузка . Patrial.
      // 2016 ( websockets. comet . AJAX )

// AJAX (browser) ---> request ---> SERVER ---> process
                    //             <--- response (data)
// websockets1 (browser) -----> request -----> SERVER ----> process
                    //                          <--- response (data)
// websockets2 (browser) <----- notice (SERVER)

// MIME types -> FORMAT ( xml,json,text )
// request -> <- response
// VERBS ( GET,POST,OPTIONS,TRACE,.... http )
// status <<<<<<< server ( cod )
// 200 - Ok
// 403 - forbidden
// 404 - not found
// ...............
// ready state ( cod ) = step
// Состояние готовности
// 4-> done (Готово)
