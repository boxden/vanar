/*при помощи промпт прочитать имя и фамилие человека в 2 отдельные переменные
иван прокопан
вывести его инициаллы
" I.P."
" Ivan" "Prokopan"
"I. P."
*/

var name = ("Ivan");
var subname = ("Jorin");
console.log( name, subname);

"Ivan".splice(0,2)
