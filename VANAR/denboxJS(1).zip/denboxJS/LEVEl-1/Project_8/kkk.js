function hello(){
  console.log("HELLO")
}
setInterval(hello , 1000)
