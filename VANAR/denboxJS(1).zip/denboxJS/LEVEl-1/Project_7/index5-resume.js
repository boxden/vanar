
// 3) es2015
//
var hello = () => {
  console.log( " Hello! ");
}

var hello = () => console.log( "Hello!" )
