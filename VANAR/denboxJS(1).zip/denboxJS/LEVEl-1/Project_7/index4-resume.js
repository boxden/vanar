///////////////////
function euro(){
  return 21.50;
}
///////////////////
console.log(   euro() * 10 );
