
function number( number1 , number2 , number3 ){
  alert(number2);
  return value;
}
number( 10, 9 , 8 );
