<?php

// Router::get("hellow", function(){echo "Hellow";});
// Router::get("bye", function(){echo "bye";});
// Router::get("logout", function(){echo "logout";});
// print "<pre>";
// var_dump(Router::$list);
//
// $URL = 'log';
// Router::execute( $URL );

$t= new Torrent ("Film", "Comedy", "Name" , "File", "Image");
$t->save;

 ?>
