<html>
<title>index</title>

<body>
<?php

// r( 'home', ['name'=>'valodea']);
// /////////////////////////////////////////////////
//  if(isset($_GET['image'])){
//
// FileHelper::getImage( $_GET['image'] );
//
// }
// ///////////////////////////////////////////////
// if(isset($_GET['style'])){
//
//   FileHelper::getStyle( $_GET['style'] );
// }
////////////////////////////////////////////



include './app/bootstrap.php';


?>

</body>
